data <- read.csv('data1.csv',header = T,row.names = 1)
tax <- data[,1:7]
write.csv(tax,'taxonomy.csv')
c <- data[,8:15]
write.csv(c,'control.csv')
m <- data[,16:23]
write.csv(m,'moderate.csv')
s <- data[,24:31]
write.csv(s,'severe.csv')

# 创建 cor.mtest 函数
cor.mtest <- function(mat, ...) {
  mat <- as.matrix(mat)
  n <- ncol(mat)
  p.mat <- matrix(NA, n, n)
  diag(p.mat) <- 0
  for (i in 1:(n - 1)) {
    for (j in (i + 1):n) {
      tmp <- cor.test(mat[, i], mat[, j], ...)
      p.mat[i, j] <- p.mat[j, i] <- tmp$p.value
    }
  }
  colnames(p.mat) <- rownames(p.mat) <- colnames(mat)
  p.mat
}

# 设置文件夹名和文件名
folders <- c("control", "severe", "moderate")
files <- c("control.csv", "severe.csv", "moderate.csv")

# 定义显著性水平、符号等
sig.level <- c(0.001, 0.01, 0.05)
insig <- "label_sig"
pch <- 4
pch.col <- "black"
pch.cex <- 3
plotCI <- c("n", "square", "circle", "rect")
lowCI.mat <- NULL
uppCI.mat <- NULL

# 循环处理每个文件
for (i in 1:length(files)) {
  # 读取数据
  mdata <- read.csv(files[i], row.names = 1,header = T)
  mdata <- t(mdata)
  # 计算p值矩阵和相关系数矩阵
  mydatap <- cor.mtest(mdata)
  mydatar <- cor(mdata, method = "pearson")
  
  # 处理相关系数矩阵
  mydatar <- as.matrix(mydatar)
  diag(mydatar) <- 0
  mydatar <- as.data.frame(mydatar)
  
  # 将p值矩阵中大于0.05的部分设置为0
  mydatar[mydatap > 0.05] <- 0
  
  # 创建文件夹（如果不存在的话）
  dir.create(folders[i], showWarnings = FALSE)
  
  # 保存p值矩阵和相关系数矩阵到文件夹中
  write.csv(mydatap, file.path(folders[i], 'p.csv'), row.names = TRUE)
  write.csv(mydatar, file.path(folders[i], 'r.csv'), row.names = TRUE)
}


# 循环处理每个文件夹
for (folder in folders) {
  # 创建一个空的 data frame 用于保存三元组
  edge_df <- data.frame(from = character(), to = character(), correlation = numeric())
  
  # 读取 r.csv 文件
  r_data <- read.csv(file.path(folder, "r.csv"), row.names = 1,header = T)
  
  # 转换为矩阵
  r_matrix <- as.matrix(r_data)
  
  # 获取矩阵的行和列名
  rownames_r <- rownames(r_matrix)
  colnames_r <- colnames(r_matrix)
  
  # 获取矩阵中的非零元素的索引
  for (i in 1:nrow(r_matrix)) {
    for (j in 1:ncol(r_matrix)) {
      if (r_matrix[i, j] != 0) {
        edge_df <- rbind(edge_df, data.frame(Source = rownames_r[i], Target = colnames_r[j], Weight = r_matrix[i, j]))
      }
    }
  }
  
  # 保存每个文件夹中的 edge 数据为 edge.csv
  write.csv(edge_df, file.path(folder, "edge.csv"), row.names = FALSE)
}


# 循环处理每个文件夹
for (folder in folders) {
  # 读取 edge.csv 文件
  edge_df <- read.csv(file.path(folder, "edge.csv"))
  
  # 添加 type 列
  edge_df$Label <- ifelse(edge_df$Weight > 0, "P", 
                         ifelse(edge_df$Weight < 0, "N", NA))
  
  # 删除 correlation 列为0的行
  edge_df <- edge_df[edge_df$Weight != 0, ]
  
  # 保存修改后的 edge.csv 文件
  write.csv(edge_df, file.path(folder, "edge.csv"), row.names = FALSE)
}

# 读取当前目录的 tax.csv 文件
tax_data <- read.csv("taxonomy.csv", row.names = 1)  # 假设 tax.csv 位于当前目录

# 循环处理每个文件夹
for (folder in folders) {
  # 读取 r.csv 文件
  r_data <- read.csv(file.path(folder, "r.csv"), row.names = 1)
  
  # 筛选出行元素不全为零的行
  non_zero_rows <- rownames(r_data)[apply(r_data, 1, function(x) any(x != 0))]

  # 根据行名筛选 tax.csv 中的对应行
  selected_tax_data <- tax_data[non_zero_rows, , drop = FALSE]
  
  # 保存筛选后的数据为 node.csv
  write.csv(selected_tax_data, file.path(folder, "tax.csv"), row.names = TRUE)
}
 
for (folder in folders) {
  # 读取 node.csv 文件
  node <- read.csv(file.path(folder, "node.csv"), row.names = 1)
  tax <- read.csv(file.path(folder,"tax.csv"),row.names = 1)
  node1 <- merge(node,tax,by = 'row.names',all.x =T)
  # 保存筛选后的数据为 node1.csv
  write.csv(node1, file.path(folder, "node1.csv"), row.names = F)
}

library(tidyverse)
for (folder in folders) {
  # 读取 node.csv 文件
  node1 <- read.csv(file.path(folder, "node1.csv"), row.names = 1)
  top100 <- read.csv(file.path(folder,"top100.csv"),row.names = 1)
  node2 <- node1[row.names(node1)%in%row.names(top100),]
  edge <- read.csv(file.path(folder, "edge.csv"))
  edge1 <- edge[edge$Source%in%row.names(top100)&edge$Target %in%row.names(top100),]
  # 保存筛选后的数据为 node1.csv
#  write.csv(node2, file.path(folder, "node100.csv"), row.names = T)
  write.csv(edge1, file.path(folder, "edge100.csv"), row.names = F)
}


node <- read.csv('node.csv',header = T,row.names = 1)
library(ggplot2)
library(ggsci)
mycolor <- pal_npg()(4)
ggplot(node,aes(x=degree))+
  geom_density(aes(fill = kindom),alpha = 0.5)+
  scale_fill_manual(values = mycolor)+
#  scale_y_continuous(position = 'right')+
  xlab('Degree of nodes')+
  ylab(' ')+
  theme_bw()+
  theme(legend.position = 'bottom',legend.background = element_blank(),
        legend.title = element_blank(),
        strip.text = element_text(face = 'bold',size = 24),
        axis.text = element_text(face = 'bold',size = 18),
        axis.text.y = element_text(hjust = 10),
        axis.title = element_text(face = 'bold',size = 18),
        legend.text = element_text(face = 'bold',size = 12))+
  facet_wrap(~Treatment,ncol = 1,scales = 'free_y')
ggsave( 'degree_distribution.pdf',width = 6,height = 15)

library(dplyr)
result <- node %>%
  group_by(Treatment, kindom) %>%
  summarise(count = n(), .groups = "drop")

bacteria <- node[node$kindom=='k__Bacteria',]
fungi <- node[node$kindom=='k__Fungi',]
archaea <- node[node$kindom=='k__Archaea',]
virus <- node[node$kindom=='k__Viruses',]


# 指定要匹配的列名
match_column <- "Source"  # 替换为你需要匹配的列名

# 循环处理每个文件夹的 edge100.csv
for (folder in folders) {
  # 读取 edge100.csv 文件
  edge_data <- read.csv(file.path(folder, "edge100.csv"),header = T)
  # 添加 s_name 列，默认 NA
  edge_data$source_name <- NA
  
  # 根据列值匹配并赋值
  column_values <- edge_data[[match_column]]  # 提取匹配列的值
  edge_data$source_name[column_values %in% bacteria$Label] <- "B"
  edge_data$source_name[column_values %in% fungi$Label] <- "F"
  edge_data$source_name[column_values %in% archaea$Label] <- "A"
  edge_data$source_name[column_values %in% virus$Label] <- "V"
  
  # 保存修改后的 edge100.csv
  write.csv(edge_data, file.path(folder, "edge100.csv"), row.names = F)
}

# 指定要匹配的列名
match_column <- "Target"  # 替换为你需要匹配的列名

# 循环处理每个文件夹的 edge100.csv
for (folder in folders) {
  # 读取 edge100.csv 文件
  edge_data <- read.csv(file.path(folder, "edge100.csv"),header = T)
  # 添加 s_name 列，默认 NA
  edge_data$target_name <- NA
  
  # 根据列值匹配并赋值
  column_values <- edge_data[[match_column]]  # 提取匹配列的值
  edge_data$target_name[column_values %in% bacteria$Label] <- "B"
  edge_data$target_name[column_values %in% fungi$Label] <- "F"
  edge_data$target_name[column_values %in% archaea$Label] <- "A"
  edge_data$target_name[column_values %in% virus$Label] <- "V"
  
  # 保存修改后的 edge100.csv
  write.csv(edge_data, file.path(folder, "edge100.csv"), row.names = F)
}

# 循环处理每个文件夹的 edge100.csv
for (folder in folders) {
  # 读取 edge100.csv 文件
  edge_data <- read.csv(file.path(folder, "edge100.csv"))
  
  # 添加 interaction_type 列，拼接 source 和 target 列的值
  edge_data$interaction_type <- paste(edge_data$source_name, edge_data$target_name, sep = "_")
  
  # 保存修改后的 edge100.csv
  write.csv(edge_data, file.path(folder, "edge100.csv"), row.names = F)
}

for (folder in folders) {
  # 读取 edge100.csv 文件
  edge_data <- read.csv(file.path(folder, "edge100.csv"))
  
  result <- edge_data %>%
    group_by(interaction_type) %>%
    summarise(count = n(), .groups = "drop")
  
  # 保存修改后的 edge100.csv
  write.table(result, file.path(folder, "edge_type.txt"), row.names = F)
}

edge <- read.csv('edge.csv',header = T,row.names = 1)
result <- edge %>%
  group_by(interaction,treatment) %>%
  summarise(count = sum(count), .groups = "drop")
pal_aaas()(9)
"#E64B35FF" "#4DBBD5FF" "#00A087FF" "#3C5488FF" "#F39B7FFF" "#8491B4FF" "#91D1C2FF"

"#3B4992FF" "#EE0000FF" "#008B45FF" "#631879FF" "#008280FF" "#BB0021FF" "#5F559BFF" "#A20056FF" "#808180FF"