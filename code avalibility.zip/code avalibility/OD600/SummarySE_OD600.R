library(ggplot2)
library(ggpubr)
library(plyr)

# 自定义 summarySE 函数
summarySE <- function(data=NULL, measurevar, groupvars=NULL, na.rm=FALSE,
                      conf.interval=.95, .drop=TRUE) {
  length2 <- function (x, na.rm=FALSE) {
    if (na.rm) sum(!is.na(x)) else length(x)
  }
  datac <- ddply(data, groupvars, .drop=.drop,
                 .fun = function(xx, col) {
                   c(N    = length2(xx[[col]], na.rm=na.rm),
                     mean = mean   (xx[[col]], na.rm=na.rm),
                     sd   = sd     (xx[[col]], na.rm=na.rm))
                 }, measurevar)
  datac <- rename(datac, c("mean" = measurevar))
  datac$se <- datac$sd / sqrt(datac$N)
  ciMult <- qt(conf.interval/2 + .5, datac$N-1)
  datac$ci <- datac$se * ciMult
  return(datac)
}

# 📥 1. 读取你准备好的 CSV 文件
# 文件应包含两列："Value" 和 "TY"
x <- read.csv(file.choose(), header = TRUE)

# ✅ 2. 设置组顺序（确保与图中顺序一致）
x$TY <- factor(x$TY, levels = c("P. megaterium", "C. firmus", "Arthrobacter", 
                                "E. mori", "P. aeruginosa","E. coli" ))
x$TY <- factor(x$TY, levels = c("DTB", "DSB" ))

# ✅ 3. 计算每组的均值和标准误
yy_summary <- summarySE(data = x,
                        measurevar = "Value",
                        groupvars = c("TY"),
                        na.rm = FALSE,
                        conf.interval = 0.95)
yy_summary$TY <- factor(yy_summary$TY, 
                        levels = c("P. megaterium", "C. firmus", "Arthrobacter", 
                                   "E. mori", "P. aeruginosa","E. coli"))

yy_summary$TY <- factor(yy_summary$TY, 
                        levels = c("DTB", "DSB"))


# ✅ 4. 两两组间 t 检验 + Bonferroni 校正
pairwise_test <- pairwise.t.test(x$Value, x$TY, p.adjust.method = "bonferroni")
pval_df <- as.data.frame(as.table(pairwise_test$p.value))
colnames(pval_df) <- c("group1", "group2", "p.adj")
pval_df <- na.omit(pval_df)

# 设置比较组的顺序和位置
group_levels <- levels(x$TY)
pval_df$group1 <- factor(pval_df$group1, levels = group_levels)
pval_df$group2 <- factor(pval_df$group2, levels = group_levels)
pval_df$y.position <- seq(from = max(x$Value) * 1.05,
                          by = max(x$Value) * 0.05,
                          length.out = nrow(pval_df))
# 选择展示具体 P 值或星号
pval_df$label <- paste0("P = ", signif(pval_df$p.adj, 2))
# 或使用星号（可替换上面的语句）：
# pval_df$label <- ifelse(pval_df$p.adj < 0.001, "***",
#                  ifelse(pval_df$p.adj < 0.01, "**",
#                  ifelse(pval_df$p.adj < 0.05, "*", "ns")))

# ✅ 5. 绘图
p <- ggplot(yy_summary, aes(x = TY, y = Value, fill = TY)) +
  geom_col(position = position_dodge(0.5), width = 0.5, alpha = 0.8) +
  geom_errorbar(aes(ymin = Value - se, ymax = Value + se),
                width = 0.1, size = 0.6, position = position_dodge(0.5)) +
  geom_jitter(data = x, aes(x = TY, y = Value),
              width = 0.15, shape = 21, size = 2, stroke = 0.3,
              fill = "white", color = "black", inherit.aes = FALSE) +
  #scale_fill_npg() +
  labs(y = "OD600", x = "") +
  theme_bw() +
  theme(
    axis.text.x = element_text(size = 12, angle = 30, hjust = 1),
    axis.text.y = element_text(size = 12),
    axis.title.x = element_text(face = 1, size = 16),
    axis.title.y = element_text(face = 1, size = 16),
    strip.text.x = element_text(size = 20, face = 2),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.border = element_rect(fill = NA, color = "black", size = 1)
  ) +
  stat_pvalue_manual(pval_df,
                     label = "label",
                     xmin = "group1", xmax = "group2",
                     y.position = "y.position",
                     tip.length = 0.01,
                     size = 3.5)

# ✅ 6. 展示图形
print(p)
ggsave("barplot_with_pvalues_OD6002.pdf", p, width = 8, height = 6)
