library(vegan)
library(psych)
library(reshape2)
library(ggplot2)
library(RColorBrewer)
#data("varechem")  #示例数据
data <- read.csv(file.choose())
cor_soil <- corr.test(data[,17:24],data[,5:16], method = "spearman", adjust = "fdr")#做相关性
cp <- as.data.frame(cor_soil$p)
cr <- as.data.frame(cor_soil$r)
cr <- round(cr,2)
cp$names <- rownames(cp)
longp <- melt(cp,idvar = "names",v.names = "abd",direction = "long")
colnames(longp) <- c('na','va','p')
cr$names <- rownames(cr)
longr <- melt(cr,idvar = "names",v.names = "abd",direction = "long")
allnew <- as.data.frame(cbind(longr,longp$p))
colnames(allnew) <- c('names','variable','r','p')
#allnew$variable <- c(rep('Agriculture',9),rep('Forest',9),rep('Wetland',9),rep('Grass',9),rep('Desert',9))
allnew[which(allnew$p<0.001),'sig'] <- '***'
allnew[which(allnew$p<0.01 & allnew$p>0.001),'sig'] <- '**'
allnew[which(allnew$p<0.05 & allnew$p>0.01),'sig'] <- '*'
ggplot(allnew, aes(variable,names)) +
  geom_tile(aes(fill=r)) +
  geom_text(aes(label=r), color="black", size=4.5) + 
  geom_text(aes(label=sig), color="black", size=4.5,vjust = 1.8) + 
  scale_fill_gradient2(low='#0072B4', high='red',mid = 'white', limit=c(-1,1),name=paste0("Correlation")) + 
  labs(x=NULL,y=NULL) + 
  theme_bw(base_size = 15)+
  theme(axis.text.x = element_text(size=10,angle =45,hjust = 1,color = "black"),
        axis.text.y = element_text(size=10,color = "black"),
        axis.ticks.y = element_blank(),
        panel.background=element_blank())
ggsave("leaf_metabolites_phyllo.pdf",width = 12,height =8)
