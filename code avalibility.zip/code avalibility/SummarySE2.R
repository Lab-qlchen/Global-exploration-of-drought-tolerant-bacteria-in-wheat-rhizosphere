library(ggplot2)
library(dplyr)
library(readr)
library(ggsci)
library(patchwork)  # 用于拼图

# 读取数据
df <- read_csv(file.choose())
df$TY <- factor(df$TY, levels = c("CT", "MT", "ST", "CH", "MH", "SH"))

# 创建一个函数来绘制每个子图
plot_group <- function(data, group_name, ylab_text) {
  data_group <- data %>% filter(Group == group_name)
  
  # 计算均值和标准误
  df_summary <- data_group %>%
    group_by(TY) %>%
    summarise(
      Mean = mean(Value, na.rm = TRUE),
      SE = sd(Value, na.rm = TRUE) / sqrt(n()),
      .groups = "drop"
    )
  
  ggplot() +
    geom_col(data = df_summary, aes(x = TY, y = Mean, fill = TY), width = 0.6, alpha = 0.85) +
    geom_errorbar(data = df_summary, aes(x = TY, ymin = Mean - SE, ymax = Mean + SE), 
                  width = 0.2, linewidth = 0.5) +
    geom_jitter(data = data_group, aes(x = TY, y = Value), 
                width = 0.15, shape = 21, size = 2, stroke = 0.3,
                fill = "white", color = "black") +
    scale_fill_npg() +
    theme_bw() +
    labs(x = NULL, y = ylab_text, title = group_name) +
    theme(
      plot.title = element_text(size = 16, face = "bold", hjust = 0.5),
      axis.text = element_text(size = 12),
      axis.title.y = element_text(size = 13),
      panel.grid = element_blank(),
      panel.border = element_rect(color = "black", fill = NA, linewidth = 0.6),
      axis.line = element_blank(),
      legend.position = "none"
    )
}

# 依次绘制4个子图，每个子图指定不同Y轴标题
p1 <- plot_group(df, "AP", "Abundance of AP (mg/g)")
p2 <- plot_group(df, "BG", "BG expression (%)")
p3 <- plot_group(df, "UR", "Uptake Rate (µmol/g·h)")
p4 <- plot_group(df, "DE", "Degradation Rate (ng/g·h)")

# 拼成2x2排列
combined <- (p1 | p2) / (p3 | p4)

# 展示图像
print(combined)

# 导出PDF
ggsave("4_Plots_Individual_Y_Label.pdf", plot = combined, width = 12, height = 10, dpi = 300)
