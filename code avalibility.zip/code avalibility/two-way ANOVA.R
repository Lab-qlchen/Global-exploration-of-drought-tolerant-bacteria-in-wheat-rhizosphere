# 数据导入与预处理
soil <- read.table('DE.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
group  <- read.table('group.txt', sep = '\t', header = TRUE, stringsAsFactors = FALSE, check.names = FALSE)
soil <- merge(soil, group, by = 'sample')

# 提取 simpson 数据
simpson <- soil[ ,c('sample', 'treat', 'time', 'simpson')]
simpson$treat <- factor(simpson$treat)
simpson$time <- factor(simpson$time)

# 加载包
library(car)
library(emmeans)
library(multcompView)

# 正态性检验 QQ plot
par(mfrow = c(1, 2))
qqPlot(lm(simpson ~ treat, data = simpson), simulate = TRUE, main = 'QQ Plot (treat)', labels = FALSE, col = "#F39B7FB2")
qqPlot(lm(simpson ~ time, data = simpson), simulate = TRUE, main = 'QQ Plot (time)', labels = FALSE, col = "#F39B7FB2")

# 方差齐性检验
bartlett.test(simpson ~ treat, data = simpson)
bartlett.test(simpson ~ time, data = simpson)

# 双因素方差分析
fit <- aov(simpson ~ treat * time, data = simpson)
summary(fit)

# Bonferroni 多重比较
emmeans_result <- emmeans(fit, pairwise ~ treat * time, adjust = "bonferroni")

# 查看 Bonferroni 校正后的P值表
emmeans_result$contrasts

#不满足假设，可使用非参数方法，例如 Scheirer-Ray-Hare Test
#rcompanion 包 scheirerRayHare()

#查看各组均值及标准差
aggregate(simpson$simpson, by = list(simpson$treat, simpson$time), FUN = mean)
aggregate(simpson$simpson, by = list(simpson$treat, simpson$time), FUN = sd)

#双因素ANOVA的aov()函数书写为aov(y~A*B)的样式，表示考虑所有可能的交互项：A、B以及A和B的交互（A:B），其中A、B分别为两组因子变量。因此，双因素ANOVA的aov()函数也可书写为aov(y~A+B+A:B)的样式。
#表达式中各效应存在主次顺序，即y~A*B与y~B*A的处理方式是不同的，一般情况下，越基础性的变量越应放在表达式前面。在这里，主因素（treat）在前，次因素（times）在后。
boxplot(simpson~treat*time, data = simpson, col = c("#3C5488B2","grey","#00A087B2","red" ,"blue","#F39B7FB2"))
