library(ggplot2)
library(reshape2)
library(ggsci)
taxa=read.csv(file.choose())
head(taxa)
taxa_m<-melt(taxa,id=c("class","group"))
taxa_m$class<-factor(taxa_m$class,levels = c("CT","MT","ST","CH","MH","SH","Rewetting"))
taxa_m$group<-factor(taxa_m$group,order=1,levels = c("Phyllosphere","Rhizosphere","Endosphere"))
p<-ggplot(taxa_m, aes(x=class, y=value*100,fill=variable)) +
  geom_bar(stat="identity")+
  theme_bw()+
  theme(axis.text.x = element_text(angle=90),
        panel.grid.major=element_blank(),
        panel.grid.minor=element_blank(),
        axis.ticks.x=element_blank(),
        axis.text.y=element_text(size=20,face=2),
        axis.title.y = element_text(size=20,face=2),
        strip.text = element_text(size=20),
        plot.margin = unit(c(0.5,0.5,0.5,0.5),"lines"))+
  labs(x='',y='Relative abundance (%)')+
  # scale_y_continuous(expand = c(0,0))+ (keyi qudiao 0-100 zhiqian de kongbai)
  scale_fill_manual(values = c("#E54B34","#4CBAD4","#009F86","#3B5387","#F29A7F","#8491B3","#91D1C1","#7E6047","#347988","#BC8B83","#CCCCCC"))+
  facet_grid(.~group)
p
ggsave("fungal.community.pdf",width =9,height =6)
