# 加载所需包
library(vegan)

# 1. 读取数据（ARG矩阵 + 分组信息）
arg <- read.csv(file.choose(), row.names = 1)   # 选择 ARG 数据（行为样本，列为基因）
arg <- t(arg)                                   # 转置为行为样本，列为特征（如 ARGs）

group <- read.csv(file.choose(), row.names = 1) # 选择对应的分组信息，包含 Treatment 和 Stage 两列

# 检查样本顺序是否一致
all(rownames(arg) == rownames(group))  # TRUE 为正常，FALSE 需手动对齐

# 2. 计算 Bray-Curtis 距离矩阵
arg.dist <- vegdist(arg, method = "bray")

# 3. 运行 PERMANOVA（分别检验 Treatment 和 Stage 的主效应）
adonis_res <- adonis2(arg.dist ~ Treatment + Stage, data = group, permutations = 999, by = "term")
#adonis_res <- adonis2(arg.dist ~ TY, data = group, permutations = 999, by = "term")
# 4. 输出结果
print(adonis_res)

# 5. 可选：保存结果为 CSV 文件
write.csv(as.data.frame(adonis_res), "PERMANOVA_Treatment_Stage_results_virus.csv")
