library(labdsv)
library(ggplot2)
library(vegan)
library(ggsci)
arg=read.csv(file.choose(),row.names=1)
arg=t(arg)
group=read.csv(file.choose(),row.names=1)
dis.bc = dsvdis (arg,'bray/curtis')
veg.pco = pco(dis.bc,k=4)
veg.pco
write.csv(veg.pco$points,file = 'P.pcoa.csv')
#write.csv(veg.pco$eig,file = "explanation.csv")
percent_var <- signif(veg.pco$eig/sum(veg.pco$eig), 4)*100
data=data.frame(veg.pco$points,group)
head(data)
data$TY<-factor(data$TY,levels = c("Phyllosphere","Rhizosphere","Endosphere"))
data$Treatment<-factor(data$Treatment,levels = c("Control","Moderate","Severe","Rewetting"))
p<-ggplot(data, aes(X1, X2))+ geom_point(aes(colour=factor(Treatment),shape=factor(Stage)),size=3,alpha=0.8)+annotate("text",x=-0.1,y=0.1,label="Adonis, P(Treatment) < 0.01**, P(Stage) < 0.01**",size=3)
p<-p+theme_bw()+theme(axis.text.x=element_text(size=9), axis.text.y=element_text(size=9),
                      axis.title.x = element_text(face=1, size=14), axis.title.y = element_text(face=1, size=14, angle=90),panel.grid.major = element_blank(),  panel.grid.minor = element_blank(),panel.border = element_rect(fill=NA,color = "black",size = 1.5))+scale_color_brewer(palette = "Set2")
p<-p+geom_vline(xintercept = 0,)+geom_hline(yintercept = 0)+labs(x=paste0("PCo1 (",percent_var[1],"%)"),y=paste0("PCo2 (",percent_var[2],"%)"))
#p<-p+scale_color_manual(values = c("#8DD3C7","#e31a1c","#FB8072","#BEBADA","#80B1D3","#FDB462","#B3DE69","#FCCDE5",
                                  # "#D9D9D9","#BC80BD","#CCEBC5","#FFED6F","#A6CEE3","#1F78B4","darkkhaki"))
#p<-p+scale_x_continuous(breaks = seq(-0.5,0.5,0.8),limits = c(-0.5,0.5))+ylim(-0.3,0.3)
p
p2=p+scale_color_npg()
p2
all.dist <- vegdist(arg)
adonis(all.dist ~ ., group, perm=200)
ggsave("PCoA.endo.bacteria.pdf",width = 5,height =3.5)

