library(randomForest)
##importance，find the important factors

data<-read.csv(file.choose(),row.names = 1,header = T)
head(data)
set.seed(2)
data.rf <- randomForest(Efpco1~., data=data, ntree=10000,keep.forest=FALSE, importance=TRUE)
plot(data.rf)
print(data.rf)
importance(data.rf)
b<-importance(data.rf)
b
varImpPlot(data.rf)
write.csv(b,quote = F,file = "leAF_Efpco1_C.csv")
randomForest(Efpco1~., data=data, ntree=5000,keep.forest=FALSE, importance=TRUE)
library(A3)
library(xtable)
library(pbapply)
a3(Efpco1 ~ .+0, data, randomForest, p.acc = 0.01, model.args = list(ntree = 100))
library(ggplot2)
library(ggpubr)
library(forcats)
MSE<-read.csv(file.choose())
MSE
p<-MSE %>%
  mutate(name = fct_reorder(name, value)) %>%
  ggplot( aes(x=name, y=value)) +
  geom_bar(stat="identity", fill="black", alpha=.6, width=.4) +
  coord_flip() +
  xlab("") +
  theme_bw()
p
p1<-p+labs(x="",y="Increase in MSE (%)")+annotate("text",x=3.5,y=20,label="explaination= 21.6%,p<0.05,ntree=10000",size=5)
p1
ggsave("RF.C_endo_Fpcoa1.pdf",width = 5,height =3.5)
