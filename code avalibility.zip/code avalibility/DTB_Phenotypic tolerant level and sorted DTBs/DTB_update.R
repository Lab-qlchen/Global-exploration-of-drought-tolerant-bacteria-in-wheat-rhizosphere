﻿library(ggplot2)
library(reshape2)
library(scales)
library(RColorBrewer)
### Normalized CD
x <- read.delim('clipboard',header = T,check.names = F)
#y<-read.csv(file.choose(),header = T)
x_m <- melt(x,
            variable = 'sample',na.rm = TRUE)
grp <- read.delim('clipboard',header = T,check.names = F) 
x_mg<-merge(x_m,grp,by='sample',all.x=TRUE)
x_mg$treat <- factor(x_mg$treat,levels = c('Control','Moderate','Severe'))
x_mg$time <- factor(x_mg$time, levels = c('Tillering','Heading'))
p1<-ggplot(x_mg,aes(x=treat,y=value,fill=treat))+
  geom_boxplot(width = 0.62, alpha=0.7,fatten =0.25,outliers = FALSE)+
  geom_jitter(aes(fill=treat),height = 0, width= 0.08,shape=21,size=0.5,alpha=0.5,color='black')+
  scale_fill_manual(values = c(brewer.pal(7,'Set2')))+
  stat_summary(fun = mean, geom = 'point', shape=21, fill = 'white', size = 1.5)+
  scale_y_continuous(#labels = scales::percent,
    breaks = seq(0,6,1.5),expand = c(0,0),limits = c(0,6))+
  geom_hline(yintercept =1.264,colour='red',alpha=0.6,linewidth=0.1,linetype=6) +
  facet_grid(.~time,scales = 'free',space = 'free')+
  labs(x=' ',y='Normalized C–D ratio')+
  theme_bw(base_size = 8)+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_line(linewidth = 0.25),
        axis.text = element_text(color = 'black'),
        axis.text.x = element_text(angle = 45,hjust = 1,vjust = 1),
        axis.title.x = element_blank(),
        panel.spacing = unit(0.04,'inches'),
        legend.position = 'none')
p1

###DTB Phenotypic level
library(ggplot2)
library(reshape2)
library(scales)
library(paletteer)
library(RColorBrewer)
library(plyr)
y <- read.delim('clipboard',header = T,check.names = F)
y_m <- melt(y,variable = 'sample',na.rm = TRUE)
grp <- read.delim('clipboard',header = T,check.names = F) 
y_mg<-merge(y_m,grp,by='sample',all.x=TRUE)
y_stat<-ddply(y_mg,.(grp,treat,time),
               summarise, mean = round(mean(value), 3),
               sd = round(sd(value), 3))
#
write.csv(y_mg,file = 'E:/project/DTB/Wheat_process/y_mg_point.csv')
##
y_stat$treat <- factor(y_stat$treat,levels = c('Control','Moderate','Severe'))
y_stat$time <- factor(y_stat$time, levels = c('Tillering','Heading'))
## plot
p2 <- ggplot(y_stat,aes(treat,mean,fill=treat))+
  geom_bar(width = 0.62, alpha=0.7,stat = 'identity')+
  #geom_jitter(aes(treat,value),size=1,shape = 1, width = 0.15)+
  geom_errorbar(aes(ymin=mean-sd,ymax=mean+sd), width=0.3,size=0.2)+
  scale_fill_manual(values = c(brewer.pal(7,'Set2')))+
  scale_y_continuous(breaks = seq(0,4,1),expand = c(0,0),limits = c(0,4))+
  facet_grid(.~time,scales = 'free',space = 'free')+
  labs(x='',y='Drought tolerant level')+
  theme_bw(base_size = 8)+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_line(linewidth = 0.25),
        axis.text = element_text(color = 'black'),
        axis.text.x = element_text(angle = 45,hjust = 1,vjust = 1),
        axis.title.x = element_blank(),
        panel.spacing = unit(0.04,'inches'),
        legend.position = 'none')
p2
### percent
### bar
z <- read.delim('clipboard',header = T,check.names = F)
grp <- read.delim('clipboard',header = T,check.names = F) 
z_mg<-merge(z,grp,by='sample',all.x=TRUE)
z_stat<-ddply(z_mg,.(grp,treat,time),
              summarise, mean = round(mean(value), 3),
              sd = round(sd(value), 3))
z_sm<-merge(z_mg[,c(1,2,5)],z_stat,by ='grp',sort = 0)
z_stat <- z_sm
##
z_stat$treat <- factor(z_stat$treat,levels = c('Control','Moderate','Severe'))
z_stat$time <- factor(z_stat$time, levels = c('Tillering','Heading'))
## plot
p3 <- ggplot(z_stat,aes(treat,mean*100,fill=treat))+
  geom_bar(aes(treat,mean/3*100),width = 0.62, alpha=0.7,stat = 'identity')+
  geom_jitter(aes(treat,value*100),size=1,shape = 1, width = 0.15)+
  geom_errorbar(aes(ymin=100*(mean-sd),ymax=100*(mean+sd)), width=0.3,size=0.2)+
  scale_fill_manual(values = c(brewer.pal(7,'Set2')))+
  scale_y_continuous(breaks = seq(0,100,20),expand = c(0,0),limits = c(-0.6,100))+#,labels = scales::percent
  facet_grid(.~time,scales = 'free',space = 'free')+
  labs(x='',y='DTB percentage (%)')+
  theme_bw(base_size = 8)+
  theme(panel.grid.minor = element_blank(),
        panel.grid.major = element_line(size = 0.25),
        axis.text = element_text(color = 'black'),
        axis.text.x = element_blank(),
        axis.title.x = element_blank(),
        panel.spacing = unit(0.04,'inches'),
        legend.position = 'none')
p3

###
library(patchwork)
p0 <- p1|p3/p2
p0
ggsave('DTB_phenotypic_end3.pdf',width = 4.5,height = 3)


