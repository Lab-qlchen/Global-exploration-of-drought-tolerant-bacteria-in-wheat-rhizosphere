# 加载必要的包
library(multcomp)
library(ggplot2)

# 选择并读取文件（假设是 CSV 格式，含 Value 和 TY 两列）
df <- read.csv(file.choose())

# 确保 TY 为因子，并指定顺序（可省略这步）
df$TY <- factor(df$TY, levels = c("Control", "Moderate", "Severe"))

# 一元方差分析
anova_res <- aov(Value ~ TY, data = df)
summary(anova_res)

# 事后两两比较（Bonferroni 校正）
mc_res <- glht(anova_res, linfct = mcp(TY = "Tukey"))
summary(mc_res, test = adjusted("bonferroni"))

# 可视化结果（箱线图 + 抖动点）
ggplot(df, aes(x = TY, y = Value, fill = TY)) +
  geom_boxplot(width = 0.6, outlier.shape = NA, alpha = 0.7) +
  geom_jitter(width = 0.1, size = 2) +
  theme_minimal() +
  labs(title = "One-way ANOVA with Bonferroni-corrected pairwise comparisons",
       x = "Treatment", y = "Value") +
  theme(legend.position = "none")
