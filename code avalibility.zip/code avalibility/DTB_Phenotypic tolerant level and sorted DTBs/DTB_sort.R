### plot ##
library(ggplot2)
library(reshape2)
# point
x <- read.delim('clipboard',header = T,check.names = F)
head(x,2)
x$class <- factor(x$class,levels = c('Sorted','Discard'))
xp <- ggplot(x,aes(class,NorCD))+
  #geom_bar(aes(fill = class),stat = 'identity',width = 0.62, alpha=0.7)+
  geom_jitter(aes(fill = class,shape=class), alpha=0.6, size=1.2,stroke=0.1, width = 0.15)+ # ,shape=21
  #scale_y_continuous(labels = scales::percent,breaks = seq(0,0.25,0.05),expand = c(0.01,0),limits = c(0,0.23))+#
  #scale_y_continuous(#breaks = seq(0,0.05,0.01),
  #breaks = seq(0,4.5,1),expand = c(0,0),limits = c(0,4.5))+
  scale_shape_manual(values = c(24,25))+
  geom_hline(yintercept =1.264,colour='red',alpha=0.7,linewidth=0.3,linetype=5) +
  scale_fill_manual(values = c('#E7298A','#66A61E'))+# ,#'#BC80BD','#CCEBC5'
  labs(y = 'Normalized C–D ratio')+
  #facet_grid(~type,scales = 'free',space = 'free')+
  theme_bw(base_size = 8)+
  theme(axis.text=element_text(colour="black"),
        axis.text.x = element_text(angle = 45,hjust = 1,vjust = 1),
        axis.title.x = element_blank(),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_line(linewidth = 0.25),
        panel.spacing = unit(0.04,'inches'),
        legend.position = 'none')
xp
#ggsave('DTB_jit_sorted_discard.pdf',width = 3,height = 6)

# spectra
y <- read.delim('clipboard',header = T,check.names = F)
head(y,2)
y_m <- melt(y,id.vars = 'wn',
            variable = 'spec',na.rm = TRUE)
head(y_m,2)
grp <- read.delim('clipboard',header = T,check.names = F)
y_md <- merge(y_m,grp,by = 'spec')
head(y_md,2)
y_md$grp <- factor(y_md$grp,levels = c('Sorted','Discard'))
y_p<-ggplot(y_md,aes(wn,value,group = spec))+
  geom_line(aes(wn,value,color = grp),linewidth = 0.1)+
  labs(x="Raman shift / cm-1",y="Intensity / a.u.")+
  scale_x_continuous(breaks = seq(600,3200,400),expand = c(0.01,0))+
  scale_y_continuous(expand = c(0.01,0),limits = c(0,8.5))+#
  scale_color_manual(values = c('#E7298A','#66A61E'))+
  annotate(geom = "rect",xmin = 2040,xmax = 2300, ymin=-Inf,ymax=Inf,fill="#666666",alpha=0.1)+
  annotate(geom = "rect",xmin = 2800,xmax = 3100, ymin=-Inf,ymax=Inf,fill="#666666",alpha=0.1)+
  theme_bw(base_size = 8)+
  theme(axis.text=element_text(colour="black"),
        axis.text.x = element_text(angle = 0,hjust = 0.5,vjust = 1),
        axis.text.y = element_blank(),
        axis.ticks.y = element_blank(),
        panel.grid.minor = element_blank(),
        panel.grid.major = element_line(linewidth = 0.25),
        panel.spacing = unit(0.04,'inches'),
        legend.position = 'none')
y_p
#ggsave('DTB_spec_sorted_discard.pdf',width = 5,height = 6)
###
library(patchwork)
xy_p <- xp+y_p+
  plot_layout(widths = c(1, 5))
xy_p

ggsave('DTB_sort_endne2.pdf',width = 3,height = 2.7)

