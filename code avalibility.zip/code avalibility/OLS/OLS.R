library(ggplot2)
library(reshape2)
x=read.csv(file.choose())
head(x)
p<-ggplot(x, aes(x=spei, y=shannon))+geom_point(size=2,alpha=0.8,color ="blue")+geom_smooth(method = "lm",size=2,colour="black",level=0.95)

p
p<-p+theme_bw()+theme(axis.text.x=element_text(size=18), axis.text.y=element_text(size=18),
                      axis.title.x = element_text(face=1, size=22), axis.title.y = element_text(face=1, size=22, angle=90),
                      strip.text.x=element_text(size=28,face=2), 
                      panel.border = element_rect(fill=NA,color = "black",size = 1.5))
p
p<-p+theme(legend.position = c(0.8,0.2),legend.background = element_blank())+annotate("text",x=0,y=4,label="slope= -0.514, r2=0.02,p<0.0001",size=8)
p

p<-p+scale_fill_manual(values=c("grey","blue"))
#p<-p+scale_y_continuous(breaks = seq(-0.05,0.1,0.03),limits = c(-0.05,0.1))
p


x=read.csv(file.choose())
head(x)
fit<-lm(spei~shannon, data=x)
summary(fit)

ggsave("spei~shannon_0106.pdf",width =9 ,height =6)
