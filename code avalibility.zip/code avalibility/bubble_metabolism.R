library (ggplot2)
library (reshape2)
data=read.csv(file.choose())
data$Sample = factor(data$Sample, levels=c('CT','MT','ST','CH','MH','SH'))
figure <- ggplot (data, aes (x=Sample, y=eggNOG.pathway, size=Abundance, color=Treatment))
figure <- figure + geom_point( ) + facet_grid(.~Treatment)
figure
figure <- figure + theme(axis.text.x = element_text(angle = 45,hjust = 1,vjust = 1))

figure + theme(panel.background = element_blank(),panel.grid.major = element_blank(),  panel.grid.minor = element_blank(),panel.border = element_rect(fill=NA,color = "black",size = 1.5))+scale_color_brewer(palette = "Set2") 
